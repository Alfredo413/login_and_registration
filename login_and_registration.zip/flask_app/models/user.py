from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

class User:
    def __init__(self, user):
        self.id = user['id']
        self.first_name = user['first_name']
        self.last_name = user['last_name']
        self.email = user['email']
        self.password = user['password']
        self.updated_at = user['updated_at']
        self.created_at = user['created_at']

    @classmethod
    def save(cls,data):
        query = 'INSERT INTO users (first_name,last_name,email,password) VALUES (%(first_name)s,%(last_name)s,%(email)s,%(password)s)'
        return connectToMySQL('login_and_registration').query_db(query,data)

    @classmethod
    def get_all(cls):
        query = 'SELECT * FROM users;'
        results=connectToMySQL('login_and_registration').query_db(query)
        users=[]
        for i in results:
            users.append(cls(i))
        return users

    @classmethod
    def get_email(cls,data):
        query = 'SELECT * FROM users WHERE email = %(email)s;'
        results=connectToMySQL('login_and_registration').query_db(query,data)
        if len(results) < 1:
            return False
        return cls(results[0])

    @classmethod
    def get_id(cls,data):
        query = 'SELECT * FROM users WHERE id = %(id)s;'
        results=connectToMySQL('login_and_registration').query_db(query,data)
        return cls(results[0])

    @staticmethod
    def reg_validate(user):
        query = 'SELECT * FROM users WHERE email = %(email)s;'
        results=connectToMySQL('login_and_registration').query_db(query,user)
        validity=True
        if len(results) != 0:
            flash('Email is already taken','register')
            validity=False
        if not EMAIL_REGEX.match(user['email']):
            flash('Email invalid','register')
            validity=False
        if len(user['first_name']) < 2:
            flash('First name must be at least 2 characters','register')
            validity=False
        if len(user['last_name']) < 2:
            flash('Last name must be at least 2 characters', 'register')
            validity=False
        if len(user['password']) < 8:
            flash('Password must be at least 8 characters','register')
            validity=False
        if user['password'] != user['confirm']:
            flash('Passwords do not match','register')
        return validity