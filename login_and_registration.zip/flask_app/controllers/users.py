from flask import render_template,redirect,session,request,flash
from flask_app import app
from flask_app.models.user import User
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)

@app.route('/')
def index():
    return redirect('/login')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/logging', methods=['POST'])
def logging():
    uservar=User.get_email(request.form)
    if not uservar:
        flash('Email Invalid','login')
        return redirect('/login')
    if not bcrypt.check_password_hash(uservar.password, request.form['password']):
        flash('Incorrect Password', 'login')
        return redirect('/login')
    session['user_id'] = uservar.id
    return redirect('/home')

@app.route('/register')
def register():
    return render_template('register.html')

@app.route('/registering',methods=['POST'])
def registering():
    if not User.reg_validate(request.form):
        return redirect('/register')
    data={
        'first_name': request.form['first_name'],
        'last_name': request.form['last_name'],
        'email': request.form['email'],
        'password': bcrypt.generate_password_hash(request.form['password'])
        }
    session['user_id'] = User.save(data)
    return redirect('/home')

@app.route('/home')
def dashboard():
    if 'user_id' not in session:
        return redirect('/logout')
    data={
        'id': session['user_id']
        }
    return render_template('home.html', user=User.get_id(data))

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')